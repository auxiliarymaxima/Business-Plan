package com.guyana.businessplan;
import android.app.*;import android.os.*;import android.webkit.*;import android.widget.*;import android.print.*;import android.content.*;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);web.addJavascriptInterface(new Bridge(),"Android");web.setWebViewClient(new WebViewClient());web.loadUrl("file:///android_asset/index.html");}
 public class Bridge { @JavascriptInterface public void toast(String m){runOnUiThread(()->Toast.makeText(MainActivity.this,m,Toast.LENGTH_SHORT).show());} @JavascriptInterface public void printPlan(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);pm.print("Business Plan",web.createPrintDocumentAdapter("Guyana Business Plan"),new PrintAttributes.Builder().build());});}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
