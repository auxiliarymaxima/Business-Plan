# Guyana Business Plan Builder v3
A real Android Studio/Gradle project recovered from the previous incomplete APK.

## Build a genuine APK
1. Open this folder in Android Studio (or AndroidIDE with Android SDK 35 installed).
2. Allow Gradle sync to finish.
3. Build > Build APK(s).
4. The APK will be under app/build/outputs/apk/debug/app-debug.apk.

The app itself works offline. Internet permission is retained for future MMG/payment links.
